#include <stdio.h>

int main(void) {
    int d,m,y;
    printf("Enter date in d m y format : ");
    scanf("%d %d %d",&d,&m,&y);
    
}